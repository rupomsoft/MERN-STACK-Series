const app=require("./app");
app.listen(5000,function () {
    console.log("App Run @5000")
})